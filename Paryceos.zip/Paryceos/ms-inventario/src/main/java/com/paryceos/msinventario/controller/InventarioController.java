package com.paryceos.msinventario.controller;

import com.paryceos.msinventario.model.Inventario;
import com.paryceos.msinventario.service.InventarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/inventario")
public class InventarioController {

    @Autowired
    private InventarioService inventarioService;

    @GetMapping
    public List<Inventario> listar() {
        return inventarioService.listar();
    }

    @GetMapping("/{id}")
    public Inventario buscar(@PathVariable Long id) {
        return inventarioService.buscar(id);
    }

    @PostMapping
    public Inventario crear(@RequestBody Inventario articulo) {
        return inventarioService.guardar(articulo);
    }

    @PutMapping("/{id}")
    public Inventario actualizar(@PathVariable Long id, @RequestBody Inventario articulo) {
        return inventarioService.actualizar(id, articulo);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        inventarioService.eliminar(id);
    }
}
