package com.paryceos.msinventario.service;

import com.paryceos.msinventario.model.Inventario;
import com.paryceos.msinventario.repository.InventarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InventarioService {

    @Autowired
    private InventarioRepository inventarioRepository;

    public List<Inventario> listar() {
        return inventarioRepository.findAll();
    }

    public Inventario buscar(Long id) {
        return inventarioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Articulo no encontrado"));
    }

    public Inventario guardar(Inventario articulo) {
        if (articulo.getStock() == null || articulo.getStock() < 0) {
            throw new RuntimeException("El stock no puede ser menor a 0");
        }
        return inventarioRepository.save(articulo);
    }

    public Inventario actualizar(Long id, Inventario datos) {
        Inventario art = buscar(id);
        art.setArticulo(datos.getArticulo());
        art.setStock(datos.getStock());
        return inventarioRepository.save(art);
    }

    public void eliminar(Long id) {
        inventarioRepository.deleteById(id);
    }
}
