package com.paryceos.mspagos.service;

import com.paryceos.mspagos.model.Pago;
import com.paryceos.mspagos.repository.PagoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;

@Service
public class PagoService {

    @Autowired
    private PagoRepository pagoRepository;

    @Autowired
    private WebClient.Builder webClientBuilder;

    public List<Pago> listar() {
        return pagoRepository.findAll();
    }

    public Pago buscar(Long id) {
        return pagoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Pago no encontrado"));
    }

    public Pago registrar(Pago pago) {
        if (pago.getMontoTotal() == null || pago.getMontoTotal() <= 0) {
            throw new RuntimeException("El monto debe ser mayor a 0");
        }

        // Validar que el evento exista en ms-eventos
        try {
            webClientBuilder.build()
                    .get()
                    .uri("http://localhost:8085/api/eventos/" + pago.getIdEvento())
                    .retrieve()
                    .bodyToMono(Object.class)
                    .block();
        } catch (Exception e) {
            throw new RuntimeException("El evento con id " + pago.getIdEvento() + " no existe");
        }

        pago.setEstado("Pendiente");
        return pagoRepository.save(pago);
    }

    public Pago actualizar(Long id, Pago datos) {
        Pago p = buscar(id);
        p.setMontoTotal(datos.getMontoTotal());
        p.setEstado(datos.getEstado());
        return pagoRepository.save(p);
    }

    public void eliminar(Long id) {
        pagoRepository.deleteById(id);
    }
}
