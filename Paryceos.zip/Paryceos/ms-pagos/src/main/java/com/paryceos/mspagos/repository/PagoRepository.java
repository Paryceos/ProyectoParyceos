package com.paryceos.mspagos.repository;

import com.paryceos.mspagos.model.Pago;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PagoRepository extends JpaRepository<Pago, Long> {
}
