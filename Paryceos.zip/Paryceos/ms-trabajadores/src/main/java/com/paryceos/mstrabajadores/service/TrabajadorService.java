package com.paryceos.mstrabajadores.service;

import com.paryceos.mstrabajadores.model.Trabajador;
import com.paryceos.mstrabajadores.repository.TrabajadorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TrabajadorService {

    @Autowired
    private TrabajadorRepository trabajadorRepository;

    public List<Trabajador> listar() {
        return trabajadorRepository.findAll();
    }

    public Trabajador buscar(Long id) {
        return trabajadorRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Trabajador no encontrado"));
    }

    public Trabajador guardar(Trabajador trabajador) {
        if (trabajador.getTarifaPorEvento() == null || trabajador.getTarifaPorEvento() <= 0) {
            throw new RuntimeException("La tarifa por evento debe ser mayor a 0");
        }
        return trabajadorRepository.save(trabajador);
    }

    public Trabajador actualizar(Long id, Trabajador datos) {
        Trabajador t = buscar(id);
        t.setNombre(datos.getNombre());
        t.setRol(datos.getRol());
        t.setTarifaPorEvento(datos.getTarifaPorEvento());
        return trabajadorRepository.save(t);
    }

    public void eliminar(Long id) {
        trabajadorRepository.deleteById(id);
    }
}
