package com.paryceos.mstrabajadores;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsTrabajadoresApplication {
    public static void main(String[] args) {
        SpringApplication.run(MsTrabajadoresApplication.class, args);
    }
}
