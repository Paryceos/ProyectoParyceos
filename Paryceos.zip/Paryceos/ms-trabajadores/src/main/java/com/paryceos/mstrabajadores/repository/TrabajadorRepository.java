package com.paryceos.mstrabajadores.repository;

import com.paryceos.mstrabajadores.model.Trabajador;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TrabajadorRepository extends JpaRepository<Trabajador, Long> {
}
