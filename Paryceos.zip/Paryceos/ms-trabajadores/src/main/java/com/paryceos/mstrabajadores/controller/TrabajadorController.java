package com.paryceos.mstrabajadores.controller;

import com.paryceos.mstrabajadores.model.Trabajador;
import com.paryceos.mstrabajadores.service.TrabajadorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/trabajadores")
public class TrabajadorController {

    @Autowired
    private TrabajadorService trabajadorService;

    @GetMapping
    public List<Trabajador> listar() {
        return trabajadorService.listar();
    }

    @GetMapping("/{id}")
    public Trabajador buscar(@PathVariable Long id) {
        return trabajadorService.buscar(id);
    }

    @PostMapping
    public Trabajador crear(@RequestBody Trabajador trabajador) {
        return trabajadorService.guardar(trabajador);
    }

    @PutMapping("/{id}")
    public Trabajador actualizar(@PathVariable Long id, @RequestBody Trabajador trabajador) {
        return trabajadorService.actualizar(id, trabajador);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        trabajadorService.eliminar(id);
    }
}
