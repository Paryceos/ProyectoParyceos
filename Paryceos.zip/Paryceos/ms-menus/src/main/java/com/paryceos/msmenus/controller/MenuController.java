package com.paryceos.msmenus.controller;

import com.paryceos.msmenus.model.Menu;
import com.paryceos.msmenus.service.MenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/menus")
public class MenuController {

    @Autowired
    private MenuService menuService;

    @GetMapping
    public List<Menu> listar() {
        return menuService.listar();
    }

    @GetMapping("/{id}")
    public Menu buscar(@PathVariable Long id) {
        return menuService.buscar(id);
    }

    @PostMapping
    public Menu crear(@RequestBody Menu menu) {
        return menuService.crear(menu);
    }

    @PutMapping("/{id}")
    public Menu actualizar(@PathVariable Long id, @RequestBody Menu menu) {
        return menuService.actualizar(id, menu);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        menuService.eliminar(id);
    }
}
