package com.paryceos.msmenus.repository;

import com.paryceos.msmenus.model.Menu;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MenuRepository extends JpaRepository<Menu, Long> {
}
