package com.paryceos.msmenus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsMenusApplication {
    public static void main(String[] args) {
        SpringApplication.run(MsMenusApplication.class, args);
    }
}
