package com.paryceos.msmenus.service;

import com.paryceos.msmenus.model.Menu;
import com.paryceos.msmenus.repository.MenuRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;

@Service
public class MenuService {

    @Autowired
    private MenuRepository menuRepository;

    @Autowired
    private WebClient.Builder webClientBuilder;

    public List<Menu> listar() {
        return menuRepository.findAll();
    }

    public Menu buscar(Long id) {
        return menuRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Menu no encontrado"));
    }

    public Menu crear(Menu menu) {
        if (menu.getNombre() == null || menu.getNombre().isEmpty()) {
            throw new RuntimeException("El nombre del menu es obligatorio");
        }
        if (menu.getPrecioPorPersona() == null || menu.getPrecioPorPersona() <= 0) {
            throw new RuntimeException("El precio por persona debe ser mayor a 0");
        }

        // Validar que el proveedor exista en ms-proveedores
        try {
            webClientBuilder.build()
                    .get()
                    .uri("http://localhost:8086/api/proveedores/" + menu.getIdProveedor())
                    .retrieve()
                    .bodyToMono(Object.class)
                    .block();
        } catch (Exception e) {
            throw new RuntimeException("El proveedor con id " + menu.getIdProveedor() + " no esta registrado");
        }

        return menuRepository.save(menu);
    }

    public Menu actualizar(Long id, Menu datos) {
        Menu m = buscar(id);
        m.setNombre(datos.getNombre());
        m.setDescripcion(datos.getDescripcion());
        m.setPrecioPorPersona(datos.getPrecioPorPersona());
        m.setIdProveedor(datos.getIdProveedor());
        return menuRepository.save(m);
    }

    public void eliminar(Long id) {
        menuRepository.deleteById(id);
    }
}
