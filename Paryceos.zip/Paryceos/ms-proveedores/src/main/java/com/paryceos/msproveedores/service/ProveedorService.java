package com.paryceos.msproveedores.service;

import com.paryceos.msproveedores.model.Proveedor;
import com.paryceos.msproveedores.repository.ProveedorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProveedorService {

    @Autowired
    private ProveedorRepository proveedorRepository;

    public List<Proveedor> listar() {
        return proveedorRepository.findAll();
    }

    public Proveedor buscar(Long id) {
        return proveedorRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Proveedor no encontrado"));
    }

    public Proveedor guardar(Proveedor proveedor) {
        if (proveedor.getNombre() == null || proveedor.getNombre().isEmpty()) {
            throw new RuntimeException("El nombre del proveedor es obligatorio");
        }
        if (proveedor.getPrecioBase() == null || proveedor.getPrecioBase() <= 0) {
            throw new RuntimeException("El precio base debe ser mayor a 0");
        }
        return proveedorRepository.save(proveedor);
    }

    public Proveedor actualizar(Long id, Proveedor datos) {
        Proveedor p = buscar(id);
        p.setNombre(datos.getNombre());
        p.setTipoServicio(datos.getTipoServicio());
        p.setTelefono(datos.getTelefono());
        p.setPrecioBase(datos.getPrecioBase());
        return proveedorRepository.save(p);
    }

    public void eliminar(Long id) {
        proveedorRepository.deleteById(id);
    }
}
