package com.paryceos.msreservas.service;

import com.paryceos.msreservas.model.Reserva;
import com.paryceos.msreservas.repository.ReservaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;

@Service
public class ReservaService {

    @Autowired
    private ReservaRepository reservaRepository;

    @Autowired
    private WebClient.Builder webClientBuilder;

    public List<Reserva> listar() {
        return reservaRepository.findAll();
    }

    public Reserva buscar(Long id) {
        return reservaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Reserva no encontrada"));
    }

    public Reserva crear(Reserva reserva) {
        if (reserva.getFecha() == null || reserva.getFecha().isEmpty()) {
            throw new RuntimeException("La fecha de la reserva es obligatoria");
        }

        // Validar que el evento exista en ms-eventos
        try {
            webClientBuilder.build()
                    .get()
                    .uri("http://localhost:8085/api/eventos/" + reserva.getIdEvento())
                    .retrieve()
                    .bodyToMono(Object.class)
                    .block();
        } catch (Exception e) {
            throw new RuntimeException("El evento con id " + reserva.getIdEvento() + " no existe");
        }

        // Validar que la ubicacion exista en ms-ubicaciones
        try {
            webClientBuilder.build()
                    .get()
                    .uri("http://localhost:8087/api/ubicaciones/" + reserva.getIdUbicacion())
                    .retrieve()
                    .bodyToMono(Object.class)
                    .block();
        } catch (Exception e) {
            throw new RuntimeException("La ubicacion con id " + reserva.getIdUbicacion() + " no existe");
        }

        reserva.setEstado("Confirmada");
        return reservaRepository.save(reserva);
    }

    public Reserva actualizar(Long id, Reserva datos) {
        Reserva r = buscar(id);
        r.setIdEvento(datos.getIdEvento());
        r.setIdUbicacion(datos.getIdUbicacion());
        r.setFecha(datos.getFecha());
        r.setEstado(datos.getEstado());
        return reservaRepository.save(r);
    }

    public void eliminar(Long id) {
        reservaRepository.deleteById(id);
    }
}
