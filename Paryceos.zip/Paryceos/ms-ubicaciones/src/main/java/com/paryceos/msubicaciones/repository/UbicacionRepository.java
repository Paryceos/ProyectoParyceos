package com.paryceos.msubicaciones.repository;

import com.paryceos.msubicaciones.model.Ubicacion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UbicacionRepository extends JpaRepository<Ubicacion, Long> {
}
