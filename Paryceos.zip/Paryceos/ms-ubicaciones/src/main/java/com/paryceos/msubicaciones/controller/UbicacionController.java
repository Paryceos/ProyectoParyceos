package com.paryceos.msubicaciones.controller;

import com.paryceos.msubicaciones.model.Ubicacion;
import com.paryceos.msubicaciones.service.UbicacionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/ubicaciones")
public class UbicacionController {

    @Autowired
    private UbicacionService ubicacionService;

    @GetMapping
    public List<Ubicacion> listar() {
        return ubicacionService.listar();
    }

    @GetMapping("/{id}")
    public Ubicacion buscar(@PathVariable Long id) {
        return ubicacionService.buscar(id);
    }

    @PostMapping
    public Ubicacion crear(@RequestBody Ubicacion ubicacion) {
        return ubicacionService.guardar(ubicacion);
    }

    @PutMapping("/{id}")
    public Ubicacion actualizar(@PathVariable Long id, @RequestBody Ubicacion ubicacion) {
        return ubicacionService.actualizar(id, ubicacion);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        ubicacionService.eliminar(id);
    }
}
