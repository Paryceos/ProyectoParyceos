package com.paryceos.msubicaciones.service;

import com.paryceos.msubicaciones.model.Ubicacion;
import com.paryceos.msubicaciones.repository.UbicacionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UbicacionService {

    @Autowired
    private UbicacionRepository ubicacionRepository;

    public List<Ubicacion> listar() {
        return ubicacionRepository.findAll();
    }

    public Ubicacion buscar(Long id) {
        return ubicacionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Ubicacion no encontrada"));
    }

    public Ubicacion guardar(Ubicacion ubicacion) {
        if (ubicacion.getNombre() == null || ubicacion.getNombre().isEmpty()) {
            throw new RuntimeException("El nombre de la ubicacion es obligatorio");
        }
        if (ubicacion.getCapacidad() == null || ubicacion.getCapacidad() <= 0) {
            throw new RuntimeException("La capacidad debe ser mayor a 0");
        }
        return ubicacionRepository.save(ubicacion);
    }

    public Ubicacion actualizar(Long id, Ubicacion datos) {
        Ubicacion u = buscar(id);
        u.setNombre(datos.getNombre());
        u.setDireccion(datos.getDireccion());
        u.setCapacidad(datos.getCapacidad());
        u.setPrecioArriendo(datos.getPrecioArriendo());
        return ubicacionRepository.save(u);
    }

    public void eliminar(Long id) {
        ubicacionRepository.deleteById(id);
    }
}
