package com.paryceos.msresenas.repository;

import com.paryceos.msresenas.model.Resena;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ResenaRepository extends JpaRepository<Resena, Long> {
}
