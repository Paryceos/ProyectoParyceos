package com.paryceos.msresenas.service;

import com.paryceos.msresenas.model.Resena;
import com.paryceos.msresenas.repository.ResenaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;

@Service
public class ResenaService {

    @Autowired
    private ResenaRepository resenaRepository;

    @Autowired
    private WebClient.Builder webClientBuilder;

    public List<Resena> listar() {
        return resenaRepository.findAll();
    }

    public Resena buscar(Long id) {
        return resenaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Resena no encontrada"));
    }

    public Resena crear(Resena resena) {
        if (resena.getPuntuacion() == null || resena.getPuntuacion() < 1 || resena.getPuntuacion() > 5) {
            throw new RuntimeException("La puntuacion debe estar entre 1 y 5");
        }

        // Validar que el cliente exista en ms-clientes
        try {
            webClientBuilder.build()
                    .get()
                    .uri("http://localhost:8081/api/clientes/" + resena.getIdCliente())
                    .retrieve()
                    .bodyToMono(Object.class)
                    .block();
        } catch (Exception e) {
            throw new RuntimeException("El cliente con id " + resena.getIdCliente() + " no esta registrado");
        }

        // Validar que el evento exista en ms-eventos
        try {
            webClientBuilder.build()
                    .get()
                    .uri("http://localhost:8085/api/eventos/" + resena.getIdEvento())
                    .retrieve()
                    .bodyToMono(Object.class)
                    .block();
        } catch (Exception e) {
            throw new RuntimeException("El evento con id " + resena.getIdEvento() + " no existe");
        }

        return resenaRepository.save(resena);
    }

    public Resena actualizar(Long id, Resena datos) {
        Resena r = buscar(id);
        r.setIdCliente(datos.getIdCliente());
        r.setIdEvento(datos.getIdEvento());
        r.setPuntuacion(datos.getPuntuacion());
        r.setComentario(datos.getComentario());
        return resenaRepository.save(r);
    }

    public void eliminar(Long id) {
        resenaRepository.deleteById(id);
    }
}
