package com.paryceos.mseventos.service;

import com.paryceos.mseventos.model.Evento;
import com.paryceos.mseventos.repository.EventoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;

@Service
public class EventoService {

    @Autowired
    private EventoRepository eventoRepository;

    @Autowired
    private WebClient.Builder webClientBuilder;

    public List<Evento> listar() {
        return eventoRepository.findAll();
    }

    public Evento buscar(Long id) {
        return eventoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Evento no encontrado"));
    }

    public Evento crear(Evento evento) {
        if (evento.getTipoFiesta() == null || evento.getTipoFiesta().isEmpty()) {
            throw new RuntimeException("El tipo de fiesta es requerido");
        }

        // Validar cliente existe en ms-clientes
        try {
            webClientBuilder.build()
                    .get()
                    .uri("http://localhost:8081/api/clientes/" + evento.getIdCliente())
                    .retrieve()
                    .bodyToMono(Object.class)
                    .block();
        } catch (Exception e) {
            throw new RuntimeException("El cliente con id " + evento.getIdCliente() + " no esta registrado");
        }

        // Validar trabajador existe en ms-trabajadores
        try {
            webClientBuilder.build()
                    .get()
                    .uri("http://localhost:8082/api/trabajadores/" + evento.getIdTrabajador())
                    .retrieve()
                    .bodyToMono(Object.class)
                    .block();
        } catch (Exception e) {
            throw new RuntimeException("El trabajador con id " + evento.getIdTrabajador() + " no esta registrado");
        }

        return eventoRepository.save(evento);
    }

    public Evento actualizar(Long id, Evento datos) {
        Evento e = buscar(id);
        e.setTipoFiesta(datos.getTipoFiesta());
        e.setIdCliente(datos.getIdCliente());
        e.setIdTrabajador(datos.getIdTrabajador());
        e.setCostoReserva(datos.getCostoReserva());
        return eventoRepository.save(e);
    }

    public void eliminar(Long id) {
        eventoRepository.deleteById(id);
    }
}
