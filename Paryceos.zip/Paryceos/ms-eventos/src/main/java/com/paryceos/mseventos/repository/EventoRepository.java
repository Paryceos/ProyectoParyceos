package com.paryceos.mseventos.repository;

import com.paryceos.mseventos.model.Evento;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EventoRepository extends JpaRepository<Evento, Long> {
}
